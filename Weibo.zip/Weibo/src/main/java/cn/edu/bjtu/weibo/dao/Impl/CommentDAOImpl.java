package cn.edu.bjtu.weibo.dao.Impl;

import cn.edu.bjtu.weibo.dao.CommentDAO;

public class CommentDAOImpl implements CommentDAO{

	@Override
	public String getComment(String commentid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTopicUserNumber(String commentid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getOwner(String commentid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTime(String commentid) {
		// TODO Auto-generated method stub
		return null;
	}
}
