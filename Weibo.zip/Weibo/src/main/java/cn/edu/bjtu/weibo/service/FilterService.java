package cn.edu.bjtu.weibo.service;

/**
 * I am not sure what is it
 * 
 * @author Liu Jinfeng
 *
 */

public interface FilterService {
	public String Filter(String content);
}
