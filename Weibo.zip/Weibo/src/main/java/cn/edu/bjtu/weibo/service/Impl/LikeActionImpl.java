package cn.edu.bjtu.weibo.service.Impl;

import java.util.List;

import cn.edu.bjtu.weibo.dao.UserDAO;
import cn.edu.bjtu.weibo.dao.WeiboDAO;
import cn.edu.bjtu.weibo.dao.Impl.UserDAOImpl;
import cn.edu.bjtu.weibo.dao.Impl.WeiboDAOImpl;
import cn.edu.bjtu.weibo.service.LikeActionService;

public class LikeActionImpl implements LikeActionService{
	
	@Override
	public boolean LikeWeiboOrCommentAction(String userId, String weiboOrCommentId) {
		UserDAO Udao = new UserDAOImpl();
		int pageIndex = 0;
		int pagePerNumber = 0;
		//User����Ӧ�ü�һ��LikeComment��List
		//û��getLikeComment����
		List<String> list = Udao.getLikeWeibo(weiboOrCommentId, pageIndex, pagePerNumber); 	
		if(list.contains(weiboOrCommentId)){
			Udao.deleteLikeWeibo(userId,weiboOrCommentId);//ȥ���ҵ���
		}else{
			Udao.insertLikeWeibo(userId,weiboOrCommentId);//�����ҵ���
		}
		return true;
	}
}
