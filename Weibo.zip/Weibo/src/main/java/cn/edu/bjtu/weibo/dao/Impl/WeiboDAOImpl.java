package cn.edu.bjtu.weibo.dao.Impl;

import java.util.List;

import cn.edu.bjtu.weibo.dao.WeiboDAO;

public class WeiboDAOImpl implements WeiboDAO {

	@Override
	public String getOwner(String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getContent(String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateContent(String weiboId, String content) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getTime(String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getWeiboPicurlOr(String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getWeiboPicurlTh(String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertWeiboPicture(String weiboId, String picId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteWeiboPicture(String weiboId, String picId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getLikeNumber(String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCommentNumber(String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForwardNumber(String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getLikeLIst(String weiboId, int pageIndex, int numberPerPage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getForwardList(String weiboId, int pageIndex, int numberPerPage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getCommentList(String weiboId, int pageIndex, int numberPerPage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteWeibo(String WeiboId) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
