package cn.edu.bjtu.weibo.model;

public enum EntityType {
	Weibo,Comment,User
}
