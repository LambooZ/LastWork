package cn.edu.bjtu.weibo.dao.Impl;

import java.util.List;

import cn.edu.bjtu.weibo.dao.UserDAO;
import cn.edu.bjtu.weibo.model.User;

public class UserDAOImpl implements UserDAO{

	@Override
	public String insertNewUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean setState(String id, boolean s) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getUserId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUserName(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateUserName(String userId, String userName) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getUserIntroduction(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateUserIntroduction(String userId, String introduction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getUserPhoneNumber(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateUserPhoneNumber(String userId, String phoneNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getUserAge(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateUserAge(String userId, String age) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getUserEmail(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateUserEmail(String userId, String email) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getUserQQ(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateUserQQ(String userId, String qq) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getUserEducation(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateUserEducation(String userId, String education) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getLocation(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateLocation(String userId, String location) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBirthday(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateBirthday(String userId, String birthday) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSex(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateSex(String userId, String sex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLastWeiboId(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateLastWeiboId(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getWeiboNumber(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateWeiboNumber(String userId, String weiboNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getWeibo(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getFollowerNumber(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateFollowerNumber(String userId, String followerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFollowingNumber(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateFollowingNumber(String userId, String followeingNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getFollowers(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertFollower(String userId, String followerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteFollower(String userId, String followerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getFollowing(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertFollowing(String userId, String followingId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteFollowing(String userId, String followingId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getForwordWeibo(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertForwordWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteForwordWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getLikeWeibo(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertLikeWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteLikeWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getCommentOnWeibo(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertCommentOnWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCommentOnWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getCommentOnComment(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertCommentOnComment(String userId, String commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCommentOnComment(String userId, String commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getFavoriteWeibo(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertFavoriteWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteFavoriteWeibo(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getGroups(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertNewGroup(String userId, String group) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteGroup(String userId, String group) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getUsersByGroup(String userId, String group, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertUserToGroup(String userId, String group, String followingUserId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteUserFromGroup(String userId, String group, String followingUserId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getWeiboAtMeMessage(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getCommentAtMeMessage(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNewComingContentAtMeMessageNumber(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertWeiboAtMe(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertCommentAtMe(String userId, String commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteWeiboAtMe(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCommentAtMe(String userId, String commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getWeiboCommentMeMessage(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getCommentCommentMeMessage(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNewComingContentCommentMeMessageNumber(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertWeiboCommentMe(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertCommentCommentMe(String userId, String commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteWeiboCommentMe(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCommentCommentMe(String userId, String commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getWeiboLikeMeMessage(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getCommentLikeMeMessage(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNewComingContentLikeMeMessageNumber(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertWeiboLikeMe(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertCommentLikeMe(String userId, String commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteWeiboLikeMe(String userId, String weiboId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCommentLikeMe(String userId, String commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> getUserAvatars(String userId, int pageIndex, int pagePerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCurrentUserAvatar(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertUserAvatar(String userId, String picId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteUserAvatar(String userId, String picId) {
		// TODO Auto-generated method stub
		return false;
	}

}
