Weibo
=

Introduction
-
We will work together to make a simple [weibo](http://weibo.com/), which focus on primary logic.

Tools
-
You need to use [eclipse](https://www.eclipse.org/downloads/) to import this project, and make sure [gradle](https://gradle.org/) installed.